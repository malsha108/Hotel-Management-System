package hotel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import net.proteanit.sql.DbUtils;

public class Department extends JFrame implements ActionListener {

    JTable table;
    JButton back;

    Department() {

        setTitle("Department Details");
        setSize(700, 500);
        setLocation(400, 200);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        // TITLE
        JLabel text = new JLabel("DEPARTMENT DETAILS");
        text.setBounds(200, 20, 300, 30);
        text.setFont(new Font("Tahoma", Font.BOLD, 22));
        add(text);

        // TABLE
        table = new JTable();

        try {
            Conn conn = new Conn();
            ResultSet rs = conn.s.executeQuery("select * from department");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(50, 80, 580, 280);
        add(sp);

        // BACK BUTTON
        back = new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.setBounds(250, 380, 120, 30);
        back.addActionListener(this);
        add(back);

        setLocationRelativeTo(null); 
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        setVisible(false);
        new Reception();
    }

    public static void main(String[] args) {
        new Department();
    }
}