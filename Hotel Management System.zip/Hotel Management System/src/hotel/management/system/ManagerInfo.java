package hotel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import net.proteanit.sql.DbUtils;

public class ManagerInfo extends JFrame implements ActionListener {

    JTable table;
    JButton back;

    ManagerInfo() {

        // FRAME SETTINGS
        setTitle("Manager Information");
        setBounds(250, 120, 1200, 650);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        // HEADING
        JLabel heading = new JLabel("MANAGER INFORMATION");
        heading.setBounds(420, 20, 400, 30);
        heading.setFont(new Font("Tahoma", Font.BOLD, 26));
        add(heading);

        // TABLE
        table = new JTable();

        try {

            Conn conn = new Conn();

            ResultSet rs = conn.s.executeQuery(
                    "select * from employee where job = 'Manager'");

            table.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (Exception e) {
            e.printStackTrace();
        }

        // TABLE DESIGN
        table.setFont(new Font("Tahoma", Font.PLAIN, 15));
        table.setRowHeight(28);

        // HEADER DESIGN
        table.getTableHeader().setFont(new Font("Tahoma", Font.BOLD, 16));
        table.getTableHeader().setBackground(Color.BLACK);
        table.getTableHeader().setForeground(Color.WHITE);

        // SCROLL PANE
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(30, 80, 1120, 420);
        add(sp);

        // BACK BUTTON
        back = new JButton("Back");
        back.setBounds(500, 540, 150, 35);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.setFont(new Font("Tahoma", Font.BOLD, 16));
        back.addActionListener(this);
        add(back);

        setLocationRelativeTo(null); 
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {

        setVisible(false);
        new Reception();
    }

    public static void main(String[] args) {

        new ManagerInfo();
    }
}