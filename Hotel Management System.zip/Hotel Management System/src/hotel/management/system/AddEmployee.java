
package hotel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AddEmployee extends JFrame implements ActionListener {

    JTextField tfname, tfemail, tfphone, tfage, tfsalary, tfaadhar;
    JRadioButton rbmale, rbfemale;
    JButton submit;
    JComboBox<String> cbjob;

    AddEmployee() {

        setLayout(null);

        // NAME
        JLabel lblname = new JLabel("NAME");
        lblname.setFont(new Font("Tahoma", Font.PLAIN, 17));
        lblname.setBounds(60, 30, 150, 27);
        add(lblname);

        tfname = new JTextField(); 
        tfname.setBounds(200, 30, 150, 30);
        add(tfname);

        // AGE
        JLabel lblage = new JLabel("AGE");
        lblage.setFont(new Font("Tahoma", Font.PLAIN, 17));
        lblage.setBounds(60, 80, 150, 27);
        add(lblage);

        tfage = new JTextField();
        tfage.setBounds(200, 80, 150, 30);
        add(tfage);

        // GENDER
        JLabel lblgender = new JLabel("GENDER");
        lblgender.setFont(new Font("Tahoma", Font.PLAIN, 17));
        lblgender.setBounds(60, 130, 150, 27);
        add(lblgender);

        rbmale = new JRadioButton("MALE");
        rbmale.setBounds(200, 130, 80, 30);
        rbmale.setBackground(Color.WHITE);
        add(rbmale);

        rbfemale = new JRadioButton("FEMALE");
        rbfemale.setBounds(280, 130, 100, 30);
        rbfemale.setBackground(Color.WHITE);
        add(rbfemale);

        ButtonGroup bg = new ButtonGroup();
        bg.add(rbmale);
        bg.add(rbfemale);

        // JOB
        JLabel lbljob = new JLabel("JOB");
        lbljob.setBounds(60, 180, 120, 30);
        lbljob.setFont(new Font("Tahoma", Font.PLAIN, 17));
        add(lbljob);

        String jobs[] = {"Front Desk Clerks", "Porters", "Housekeeping", "Kitchen Staff",
                "Room Service", "Waiter/Waitress", "Manager", "Accountant", "Chef"};

        cbjob = new JComboBox<>(jobs);
        cbjob.setBounds(200, 180, 150, 30);
        add(cbjob);

        // PHONE
        JLabel lblphone = new JLabel("PHONE");
        lblphone.setBounds(60, 230, 120, 30);
        lblphone.setFont(new Font("Tahoma", Font.PLAIN, 17));
        add(lblphone);

        tfphone = new JTextField(); 
        tfphone.setBounds(200, 230, 150, 30);
        add(tfphone);

        // SALARY
        JLabel lblsalary = new JLabel("SALARY");
        lblsalary.setBounds(60, 280, 120, 30);
        lblsalary.setFont(new Font("Tahoma", Font.PLAIN, 17));
        add(lblsalary);

        tfsalary = new JTextField();
        tfsalary.setBounds(200, 280, 150, 30);
        add(tfsalary);

        // EMAIL
        JLabel lblemail = new JLabel("EMAIL");
        lblemail.setBounds(60, 330, 120, 30);
        lblemail.setFont(new Font("Tahoma", Font.PLAIN, 17));
        add(lblemail);

        tfemail = new JTextField();
        tfemail.setBounds(200, 330, 150, 30);
        add(tfemail);

       
        JLabel lblidnumber = new JLabel("ID NUMBER");
        lblidnumber.setFont(new Font("Tahoma", Font.PLAIN, 17));
        lblidnumber.setBounds(60, 380, 120, 30);
        add(lblidnumber);

        tfaadhar = new JTextField();
        tfaadhar.setBounds(200, 380, 150, 30);
        add(tfaadhar);

        // BUTTON
        submit = new JButton("SUBMIT");
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.WHITE);
        submit.setBounds(200, 430, 150, 30);
        submit.addActionListener(this);
        add(submit);

        // IMAGE
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/tenth.jpg"));
        Image i2 = i1.getImage().getScaledInstance(450, 450, Image.SCALE_DEFAULT);
        JLabel image = new JLabel(new ImageIcon(i2));
        image.setBounds(380, 60, 450, 370);
        add(image);

        getContentPane().setBackground(Color.WHITE);
        setBounds(350, 200, 850, 540);
        setVisible(true);
    }

    public static void main(String[] args) {
        new AddEmployee();
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        String name = tfname.getText();
        String age = tfage.getText();
        String salary = tfsalary.getText();
        String phone = tfphone.getText();
        String email = tfemail.getText();
        String aadhar = tfaadhar.getText();

        String gender = null;
        
        if(name.equals("")){
            JOptionPane.showMessageDialog(null,"Name should not be empty");
        }
        if (rbmale.isSelected()) {
            gender = "Male";
        } else if (rbfemale.isSelected()) {
            gender = "Female";
        }

        String job = (String) cbjob.getSelectedItem();

        try {
            Conn c = new Conn();

            String query = "insert into employee values('" + name + "','" + age + "','" + gender + "','" + job + "','" + salary + "','" + phone + "','" + email + "','" + aadhar + "')";

            c.s.executeUpdate(query);

            JOptionPane.showMessageDialog(null, "Employee added successfully");

            setVisible(false);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}

    

