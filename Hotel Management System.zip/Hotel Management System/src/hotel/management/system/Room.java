package hotel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import net.proteanit.sql.DbUtils;

public class Room extends JFrame implements ActionListener {

    JTable table;
    JButton back;

    Room() {

        setTitle("Room Details");
        setBounds(300, 200, 1000, 600);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        // TITLE
        JLabel text = new JLabel("ROOM DETAILS");
        text.setBounds(380, 20, 250, 30);
        text.setFont(new Font("Tahoma", Font.BOLD, 22));
        add(text);

        // COLUMN HEADINGS
        JLabel l1 = new JLabel("Room Number");
        l1.setBounds(20, 70, 100, 20);
        add(l1);

        JLabel l2 = new JLabel("Availability");
        l2.setBounds(140, 70, 100, 20);
        add(l2);

        JLabel l3 = new JLabel("Status");
        l3.setBounds(270, 70, 100, 20);
        add(l3);

        JLabel l4 = new JLabel("Price");
        l4.setBounds(390, 70, 100, 20);
        add(l4);

        JLabel l5 = new JLabel("Bed Type");
        l5.setBounds(510, 70, 100, 20);
        add(l5);

        // TABLE
        table = new JTable();

        try {

            Conn conn = new Conn();

            ResultSet rs = conn.s.executeQuery("select * from room");

            table.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (Exception e) {
            e.printStackTrace();
        }

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 100, 600, 400);
        add(sp);

        // IMAGE
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("hotel/management/system/icons/eight.jpg"));

        Image i2 = i1.getImage().getScaledInstance(300, 300, Image.SCALE_DEFAULT);

        ImageIcon i3 = new ImageIcon(i2);

        JLabel image = new JLabel(i3);
        image.setBounds(650, 120, 300, 300);
        add(image);

        // BACK BUTTON
        back = new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.setBounds(250, 520, 120, 30);
        back.addActionListener(this);
        add(back);

        setLocationRelativeTo(null); 
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {

        setVisible(false);
        new Reception();
    }

    public static void main(String[] args) {

        new Room();
    }
}
   
