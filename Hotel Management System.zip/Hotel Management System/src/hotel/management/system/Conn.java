
package hotel.management.system;

import java.sql.*;

public class Conn {

    Connection c;
    public Statement s;

    public Conn() {
        try {

            // Load MySQL Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to database
            c = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/hotelmanagementsystem",
                    "root",
                    "M1234567@"
            );

            // Create statement
            s = c.createStatement();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
