package hotel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Reception extends JFrame implements ActionListener {

  
    JButton newCustomer, room, department, employee,
            customerInfo, managerInfo, checkout,
            updateCheck, updateRoom, roomChange, pickup,
            searchRoom, addEmployee, addDepartment, logout;

    public Reception() {
      
        setTitle("Reception");
        setBounds(530, 200, 900, 700); 
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        try {
            ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/fourth.jpg"));
            Image i2 = i1.getImage().getScaledInstance(500, 500, Image.SCALE_DEFAULT);
            ImageIcon i3 = new ImageIcon(i2);
            JLabel image = new JLabel(i3);
            image.setBounds(350, 80, 500, 470); 
            add(image);
        } catch (Exception e) {
            System.out.println("Image not found: " + e.getMessage());
        }

        
        newCustomer   = createButton("New Customer Form", 30);
        room          = createButton("Room", 65);
        department    = createButton("Department Details", 100);
        employee      = createButton("All Employee Info", 135);
        customerInfo  = createButton("Customer Info", 170);
        managerInfo   = createButton("Manager Info", 205);
        checkout      = createButton("Check Out", 240);
        updateCheck   = createButton("Update Check Status", 275);
        updateRoom    = createButton("Update Room Status", 310);
        roomChange    = createButton("Room Change", 345);
        pickup        = createButton("Pick Up Service", 380); 
        searchRoom    = createButton("Search Room", 415);     
        addDepartment = createButton("Add Department", 450);
        logout        = createButton("Log Out", 485);

        setLocationRelativeTo(null); 
        setVisible(true);
    }

    public JButton createButton(String text, int y) {
        JButton btn = new JButton(text);
        btn.setBounds(30, y, 220, 30); 
        btn.setBackground(Color.BLACK);
        btn.setForeground(Color.WHITE);
        btn.addActionListener(this); 
        add(btn);
        return btn;
    }

    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == newCustomer) {
            setVisible(false); 
            new AddCustomer(); 
        } else if (ae.getSource() == room) {
            setVisible(false);
            new Room();
        } else if (ae.getSource() == department) {
            setVisible(false);
            new Department();
        } else if (ae.getSource() == employee) {
            setVisible(false);
            new EmployeeInfo();
        } else if (ae.getSource() == customerInfo) {
            setVisible(false);
            new CustomerInfo();
        } else if (ae.getSource() == managerInfo) {
            setVisible(false);
            new ManagerInfo();
        } else if (ae.getSource() == checkout) {
            setVisible(false);
            try {
                new CheckOut().setVisible(true); 
            } catch(Exception e) { e.printStackTrace(); }
        } else if (ae.getSource() == updateCheck) {
            setVisible(false);
            new UpdateCheck(); 
        } else if (ae.getSource() == updateRoom) {
            setVisible(false);
            try {
                new UpdateRoom().setVisible(true); 
            } catch(Exception e) { e.printStackTrace(); }
        } else if (ae.getSource() == roomChange) { 
            setVisible(false);
            new RoomChange(); 
        } else if (ae.getSource() == pickup) {
            setVisible(false);
            new Pickup(); 
        } else if (ae.getSource() == searchRoom) {
            setVisible(false);
            new SearchRoom();
        
        } else if (ae.getSource() == addDepartment) { 
            setVisible(false);
            new AddDepartment(); 
        } else if (ae.getSource() == logout) {
            setVisible(false);
            new Login(); 
        }
    }

    public static void main(String[] args) {
        new Reception();
    }
}