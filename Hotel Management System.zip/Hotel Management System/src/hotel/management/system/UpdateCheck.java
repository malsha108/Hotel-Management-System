package hotel.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class UpdateCheck extends JFrame implements ActionListener {
    
    Choice customer;
    JTextField tfroom, tfname, tfcheckin, tfpaid, tfpending;
    JButton check, update, back;
    
    UpdateCheck() {
      
       setSize(980, 500);
       setLocation(300, 200);
       setLayout(null);
   
       JLabel text = new JLabel("Update Status");
       text.setFont(new Font("Tahoma", Font.PLAIN, 20));
       text.setForeground(Color.BLUE); 
       text.setBounds(30, 20, 200, 30);
       add(text);
       
       JLabel lblid = new JLabel("Customer Id");
       lblid.setBounds(30, 80, 100, 20);
       add(lblid);
       
       ImageIcon i1  = new ImageIcon(ClassLoader.getSystemResource("hotel/management/system/icons/nine.jpg"));
       JLabel l1 = new JLabel(i1);
       l1.setBounds(450,70,476,270);
       add(l1);
       
       customer = new Choice();
       customer.setBounds(200, 80, 150, 25);
       add(customer);
       
       try {
           Conn c = new Conn();
           ResultSet rs = c.s.executeQuery("select * from customer");
           while(rs.next()) {
               customer.add(rs.getString("number"));
           }
       } catch (Exception e) {
           e.printStackTrace();
       }
       
       JLabel lblroom = new JLabel("Room Number");
       lblroom.setBounds(30, 120, 100, 20);
       add(lblroom);
        
       tfroom = new JTextField();
       tfroom.setBounds(200, 120, 150, 25); 
       add(tfroom);
       
       JLabel lblname = new JLabel("Name");
       lblname.setBounds(30, 160, 100, 20); 
       add(lblname);
        
       tfname = new JTextField();
       tfname.setBounds(200, 160, 150, 25);
       add(tfname);
       
       JLabel lblcheckin = new JLabel("Checkin Time");
       lblcheckin.setBounds(30, 200, 100, 20); 
       add(lblcheckin);
        
       tfcheckin = new JTextField();
       tfcheckin.setBounds(200, 200, 150, 25); 
       add(tfcheckin);
       
       JLabel lblpaid = new JLabel("Amount Paid");
       lblpaid.setBounds(30, 240, 100, 20);
       add(lblpaid);
        
       tfpaid = new JTextField();
       tfpaid.setBounds(200, 240, 150, 25);
       add(tfpaid);
       
       JLabel lblpending = new JLabel("Pending Amount");
       lblpending.setBounds(30, 280, 100, 20);
       add(lblpending);
        
       tfpending = new JTextField();
       tfpending.setBounds(200, 280, 150, 25);
       add(tfpending);
       
       check = new JButton("Check");
       check.setBackground(Color.BLACK);
       check.setForeground(Color.WHITE);
       check.setBounds(30, 360, 100, 30);
       check.addActionListener(this);
       add(check);
       
       update = new JButton("Update");
       update.setBackground(Color.BLACK);
       update.setForeground(Color.WHITE);
       update.setBounds(150, 360, 100, 30); 
       update.addActionListener(this);
       add(update);
       
       back = new JButton("Back");
       back.setBackground(Color.BLACK);
       back.setForeground(Color.WHITE);
       back.setBounds(270, 360, 100, 30);
       back.addActionListener(this);
       add(back);
       
       setLocationRelativeTo(null); 
       setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource() == check) {
            String id = customer.getSelectedItem();
            
            try {
                Conn c = new Conn();
                
               
                String customerQuery = "select * from customer where number = '" + id + "'";
                Statement s1 = c.c.createStatement(); 
                ResultSet rs1 = s1.executeQuery(customerQuery);
                
                String roomNum = "";
                String depositStr = "0";
                
                if (rs1.next()) {
                    roomNum = rs1.getString("room");
                    depositStr = rs1.getString("deposite");
                    
                    tfroom.setText(roomNum);
                    tfname.setText(rs1.getString("name"));
                    tfcheckin.setText(rs1.getString("checkintime")); 
                    tfpaid.setText(depositStr);       
                }
                rs1.close();
                s1.close();
                
               
                if (!roomNum.equals("")) {
                    String roomQuery = "select * from room where roomnumber = '" + roomNum + "'";
                    Statement s2 = c.c.createStatement(); 
                    ResultSet rs2 = s2.executeQuery(roomQuery);
                    
                    if (rs2.next()) {
                        String price = rs2.getString("price");
                        
                        int totalPrice = (price != null) ? Integer.parseInt(price) : 0;
                        int amountPaid = (depositStr != null && !depositStr.isEmpty()) ? Integer.parseInt(depositStr) : 0;
                        int pendingAmount = totalPrice - amountPaid;
                        
                        tfpending.setText(String.valueOf(pendingAmount));
                    }
                    rs2.close();
                    s2.close();
                } else {
                    tfpending.setText("");
                    JOptionPane.showMessageDialog(null, "No room assigned to this customer.");
                }
                
            } catch(Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error fetching details: " + e.getMessage());
            }
       
        } else if(ae.getSource() == update) {
            String id = customer.getSelectedItem();
            String room = tfroom.getText();
            String name = tfname.getText();
            String checkin = tfcheckin.getText();
            String deposit = tfpaid.getText();
            
            try {
                Conn c = new Conn();
                c.s.executeUpdate("update customer set room = '"+room+"', name = '"+name+"', checkintime = '"+checkin+"', deposite = '"+deposit+"' where number = '"+id+"'");
                JOptionPane.showMessageDialog(null, "Data Updated Successfully");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if(ae.getSource() == back) {
            setVisible(false); 
            new Reception();   
        }
    }

    public static void main(String[] args) {
        new UpdateCheck();
    }
}
