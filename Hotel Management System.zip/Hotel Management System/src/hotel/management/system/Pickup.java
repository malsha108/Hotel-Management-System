package hotel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import net.proteanit.sql.DbUtils; 

public class Pickup extends JFrame implements ActionListener {
    
    Choice c1;
    JTable table;
    JButton btnDisplay, btnExit;

    public Pickup() {
        setTitle("Pick Up Service");
        setSize(800, 600);
        setLocation(530, 200);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
        JLabel lblPickUpService = new JLabel("Pick Up Service");
        lblPickUpService.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblPickUpService.setBounds(90, 11, 158, 25);
        add(lblPickUpService);
		
        JLabel lblTypeOfCar = new JLabel("Type of Car");
        lblTypeOfCar.setBounds(32, 97, 89, 14);
        add(lblTypeOfCar);

        c1 = new Choice();
        c1.setBounds(123, 94, 150, 25);
        add(c1);
        
        try {
            Conn c = new Conn(); 
            ResultSet rs = c.s.executeQuery("select distinct brand from driver");
            while(rs.next()) {
                c1.add(rs.getString("brand"));    
            }
        } catch(Exception e) { 
            e.printStackTrace(); 
            JOptionPane.showMessageDialog(null, "Dropdown Error: " + e.getMessage());
        }
		
        JLabel lblInfo = new JLabel("Name");
        lblInfo.setBounds(24, 208, 46, 14);
        add(lblInfo);
		
        JLabel lblNewLabel = new JLabel("Age");
        lblNewLabel.setBounds(135, 208, 46, 14);
        add(lblNewLabel);
		
        JLabel lblGender = new JLabel("Gender");
        lblGender.setBounds(250, 208, 46, 14);
        add(lblGender);
		
        JLabel lblTypeOfDriver = new JLabel("Company");
        lblTypeOfDriver.setBounds(360, 208, 80, 14);
        add(lblTypeOfDriver);
		
        JLabel lblDateOfThe = new JLabel("Car Brand");
        lblDateOfThe.setBounds(475, 208, 105, 14);
        add(lblDateOfThe);
	
        JLabel lblAirport = new JLabel("Available");
        lblAirport.setBounds(590, 208, 86, 14);
        add(lblAirport);
		
        JLabel lblAvailable = new JLabel("Location");
        lblAvailable.setBounds(700, 208, 73, 14);
        add(lblAvailable);

        // JTable
        table = new JTable();
        JScrollPane jsp = new JScrollPane(table);
        jsp.setBounds(10, 233, 765, 230);
        add(jsp);
                
        // BUTTONS
        btnDisplay = new JButton("Display");
        btnDisplay.setBounds(200, 500, 120, 30);
        btnDisplay.setBackground(Color.BLACK);
        btnDisplay.setForeground(Color.WHITE);
        btnDisplay.addActionListener(this);
        add(btnDisplay);
		
        btnExit = new JButton("Back");
        btnExit.setBounds(420, 500, 120, 30);
        btnExit.setBackground(Color.BLACK);
        btnExit.setForeground(Color.WHITE);
        btnExit.addActionListener(this);
        add(btnExit);
		
        setLocationRelativeTo(null); 
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnDisplay) { 
            try {
                Conn c = new Conn();
                
                
                String selectedBrand = c1.getSelectedItem().trim();
               
               
                String SQL = "select * from driver where brand = '" + selectedBrand + "'";
                ResultSet rs = c.s.executeQuery(SQL);
                
                table.setModel(DbUtils.resultSetToTableModel(rs));
                table.revalidate();
                table.repaint();
                
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
            }
            
        } else if (ae.getSource() == btnExit) { 
            new Reception(); 
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new Pickup();
    }
}