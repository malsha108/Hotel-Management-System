
package hotel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class UpdateRoom extends JFrame implements ActionListener {
    
    Choice c1, comboAva, comboStatus; 
    JTextField txt_Room;
    JButton b1, btnUpdate, btnExit;

    public UpdateRoom() {
        setTitle("Update Room Status");
        setSize(1000, 450);
        setLocation(530, 200);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        try {
            ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/seventh.jpg"));
            Image i3 = i1.getImage().getScaledInstance(550, 250, Image.SCALE_DEFAULT);
            JLabel l1 = new JLabel(new ImageIcon(i3));
            l1.setBounds(400, 60, 550, 250);
            add(l1);
        } catch (Exception e) {
            System.out.println("Image not found");
        }
		
        JLabel lblUpdateRoomStatus = new JLabel("Update Room Status");
        lblUpdateRoomStatus.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblUpdateRoomStatus.setBounds(85, 11, 206, 34);
        add(lblUpdateRoomStatus);
		
        JLabel lblNewLabel = new JLabel("Phone Number:");
        lblNewLabel.setBounds(27, 87, 90, 14);
        add(lblNewLabel);
                
        c1 = new Choice();
        c1.setBounds(160, 84, 140, 20);
        add(c1);
        
        try {
            Conn c = new Conn(); 
            ResultSet rs = c.s.executeQuery("select * from customer");
            while(rs.next()) {
                c1.add(rs.getString("number"));    
            }
        } catch(Exception e) { 
            e.printStackTrace(); 
        }
		
        JLabel lblRoomId = new JLabel("Room Number:");
        lblRoomId.setBounds(27, 133, 100, 14);
        add(lblRoomId);

        txt_Room = new JTextField();
        txt_Room.setBounds(160, 130, 140, 20);
        add(txt_Room);
		
        JLabel lblAvailability = new JLabel("Availability:");
        lblAvailability.setBounds(27, 187, 90, 14);
        add(lblAvailability);
		
        comboAva = new Choice();
        comboAva.add("Available");
        comboAva.add("Occupied");
        comboAva.setBounds(160, 184, 140, 20);
        add(comboAva);
		
        JLabel lblCleanStatus = new JLabel("Clean Status:");
        lblCleanStatus.setBounds(27, 240, 90, 14);
        add(lblCleanStatus);
		
        comboStatus = new Choice();
        comboStatus.add("Cleaned");
        comboStatus.add("Dirty");
        comboStatus.setBounds(160, 237, 140, 20);
        add(comboStatus);
                
        b1 = new JButton("Check");
        b1.setBounds(120, 315, 89, 23);
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.addActionListener(this);
        add(b1);
		
        btnUpdate = new JButton("Update");
        btnUpdate.setBounds(60, 355, 89, 23);
        btnUpdate.setBackground(Color.BLACK);
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.addActionListener(this);
        add(btnUpdate);
		
        btnExit = new JButton("Back");
        btnExit.setBounds(180, 355, 89, 23);
        btnExit.setBackground(Color.BLACK);
        btnExit.setForeground(Color.WHITE);
        btnExit.addActionListener(this);
        add(btnExit);
		
        setLocationRelativeTo(null); 
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b1) { 
            String s1 = c1.getSelectedItem();
            try {
                Conn c = new Conn();
                ResultSet rs1 = c.s.executeQuery("select * from customer where number = '" + s1 + "'");
                while(rs1.next()) {
                    txt_Room.setText(rs1.getString("room")); 
                }
                
                ResultSet rs2 = c.s.executeQuery("select * from room where roomnumber = '" + txt_Room.getText() + "'");
                while(rs2.next()) {
                    comboAva.select(rs2.getString("availability")); 
                    comboStatus.select(rs2.getString("cleaning_status"));
                }
            } catch(Exception ee) {
                ee.printStackTrace();
            }
            
        } else if (ae.getSource() == btnUpdate) { 
            try {
                Conn c = new Conn();
                String str = "update room set cleaning_status = '" + comboStatus.getSelectedItem() + "', availability = '" + comboAva.getSelectedItem() + "' where roomnumber = '" + txt_Room.getText() + "'";
                c.s.executeUpdate(str);
                
                JOptionPane.showMessageDialog(null, "Update Successful");
                new Reception(); 
                setVisible(false);
            } catch (Exception ee) {
                ee.printStackTrace();
            }
            
        } else if (ae.getSource() == btnExit) { 
            new Reception();
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new UpdateRoom();
    }
}
