package hotel.management.system;

import java.awt.*;
import java.awt.EventQueue;
import java.sql.*;	
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.event.*;
import java.util.Date; 

public class CheckOut extends JFrame {
    private JPanel contentPane;
    private JTextField t1;         
    private JTextField tCheckIn;     
    private JTextField tCheckOut;    
    Choice c1;

  
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    CheckOut frame = new CheckOut();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

   
    public CheckOut() throws SQLException {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        setBounds(530, 200, 850, 400); 
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
		
      
        JLabel lblCheckOut = new JLabel("Check Out ");
        lblCheckOut.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblCheckOut.setBounds(70, 11, 140, 35);
        contentPane.add(lblCheckOut);
		
        
        JLabel lblName = new JLabel("Number (ID):");
        lblName.setBounds(20, 85, 110, 14);
        contentPane.add(lblName);
                
        
        c1 = new Choice();
        try {
            Conn c = new Conn(); 
            ResultSet rs = c.s.executeQuery("select * from customer");
            while (rs.next()) {
                c1.add(rs.getString("number"));    
            }
        } catch (Exception e) { 
            e.printStackTrace();
        }
        c1.setBounds(150, 82, 150, 20);
        contentPane.add(c1);
                
       
        ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("hotel/management/system/icons/tick.png"));
        Image i5 = i4.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);
        JButton l2 = new JButton(i6);
        l2.setBounds(310, 82, 20, 20);
        contentPane.add(l2);

    
        JLabel lblRoomNumber = new JLabel("Room Number:");
        lblRoomNumber.setBounds(20, 132, 110, 20);
        contentPane.add(lblRoomNumber);
		
        t1 = new JTextField();
        t1.setBounds(150, 132, 150, 20);
        contentPane.add(t1);

      
        JLabel lblCheckIn = new JLabel("Check-In Time:");
        lblCheckIn.setBounds(20, 180, 110, 20);
        contentPane.add(lblCheckIn);

        tCheckIn = new JTextField();
        tCheckIn.setBounds(150, 180, 150, 20);
        tCheckIn.setEditable(false); 
        contentPane.add(tCheckIn);

      
        JLabel lblCheckOutTime = new JLabel("Check-Out Time:");
        lblCheckOutTime.setBounds(20, 230, 110, 20);
        contentPane.add(lblCheckOutTime);

        tCheckOut = new JTextField();
        tCheckOut.setBounds(150, 230, 150, 20);
        tCheckOut.setEditable(false); 
        contentPane.add(tCheckOut);
                
     
        l2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                try {
                    Conn c = new Conn(); 
                    String number = c1.getSelectedItem();
                    
                   
                    ResultSet rs = c.s.executeQuery("select * from customer where number = '" + number + "'");
                    
                    if (rs.next()) {
                        
                        t1.setText(rs.getString("room"));
                        tCheckIn.setText(rs.getString("checkintime")); 
                    } else {
                        JOptionPane.showMessageDialog(null, "Customer details not found!");
                    }
                    
                  
                    Date date = new Date();
                    tCheckOut.setText("" + date);
                    
                } catch (Exception e) { 
                    e.printStackTrace(); 
                    JOptionPane.showMessageDialog(null, "Error fetching details: " + e.getMessage());
                }
            }
        });
                
      
        JButton btnCheckOut = new JButton("Check Out");
        btnCheckOut.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = c1.getSelectedItem();
                String s1 = t1.getText();
                
                
                String deleteSQL = "delete from customer where number = '" + id + "'";
                String q2 = "update room set availability = 'Available' where room_number = '" + s1 + "'";
                                
                Conn c = new Conn(); 
                try {
                    c.s.executeUpdate(deleteSQL);
                    c.s.executeUpdate(q2);
                    JOptionPane.showMessageDialog(null, "Check Out Successful");
                    new Reception().setVisible(true);
                    setVisible(false);
                } catch (SQLException e1) {
                    e1.printStackTrace();
                    System.out.println(e1.getMessage());
                }
            }
        });
        btnCheckOut.setBounds(50, 300, 100, 25); 
        btnCheckOut.setBackground(Color.BLACK);
        btnCheckOut.setForeground(Color.WHITE);
        contentPane.add(btnCheckOut);
		
       
        JButton btnExit = new JButton("Back");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Reception().setVisible(true);
                setVisible(false);
            }
        });
        btnExit.setBounds(160, 300, 100, 25);
        btnExit.setBackground(Color.BLACK);
        btnExit.setForeground(Color.WHITE);
        contentPane.add(btnExit);
                
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("hotel/management/system/icons/sixth.jpg"));
        Image i3 = i1.getImage().getScaledInstance(430, 250, Image.SCALE_DEFAULT);
        ImageIcon i2 = new ImageIcon(i3);
        JLabel l1 = new JLabel(i2);
        l1.setBounds(360, 30, 430, 250);
        contentPane.add(l1);
                
        getContentPane().setBackground(Color.WHITE);
    }
}