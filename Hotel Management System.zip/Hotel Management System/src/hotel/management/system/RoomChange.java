package hotel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class RoomChange extends JFrame implements ActionListener, ItemListener {

    Choice cRoom;
    JComboBox<String> comboAvailable, comboClean, comboBed;
    JTextField tPrice;
    JButton updateBtn, cancelBtn;
    boolean isFirstLoad = true; 

    public RoomChange() {
        setTitle("Room Change & Status Update");
        setBounds(450, 200, 1000, 500); 
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        // Title
        JLabel heading = new JLabel("Room Change");
        heading.setFont(new Font("Tahoma", Font.BOLD, 18));
        heading.setBounds(150, 30, 200, 30);
        add(heading);

        JLabel lblRoom = new JLabel("Room Number");
        lblRoom.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblRoom.setBounds(60, 90, 120, 30);
        add(lblRoom);

        cRoom = new Choice();
        cRoom.setFont(new Font("Tahoma", Font.PLAIN, 14));
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from room");
            while (rs.next()) {
                cRoom.add(rs.getString("roomnumber")); 
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        cRoom.setBounds(200, 95, 160, 30);
        cRoom.addItemListener(this); 
        add(cRoom);

        JLabel lblAvailable = new JLabel("Available");
        lblAvailable.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblAvailable.setBounds(60, 140, 120, 30);
        add(lblAvailable);

        String[] availOptions = { "Available", "Occupied" };
        comboAvailable = new JComboBox<>(availOptions);
        comboAvailable.setBounds(200, 140, 160, 30);
        comboAvailable.setBackground(Color.WHITE);
        comboAvailable.addActionListener(this); 
        add(comboAvailable);

        JLabel lblClean = new JLabel("Cleaning Status");
        lblClean.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblClean.setBounds(60, 190, 120, 30);
        add(lblClean);

        String[] cleanOptions = { "Cleaned", "Not Ready", "Dirty" };
        comboClean = new JComboBox<>(cleanOptions);
        comboClean.setBounds(200, 190, 160, 30);
        comboClean.setBackground(Color.WHITE);
        add(comboClean);

        JLabel lblPrice = new JLabel("Price");
        lblPrice.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblPrice.setBounds(60, 240, 120, 30);
        add(lblPrice);

        tPrice = new JTextField();
        tPrice.setFont(new Font("Tahoma", Font.PLAIN, 14));
        tPrice.setBounds(200, 240, 160, 30);
        add(tPrice);

        JLabel lblBed = new JLabel("Bed Type");
        lblBed.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblBed.setBounds(60, 290, 120, 30);
        add(lblBed);

        String[] bedOptions = { "Single Bed", "Double Bed" };
        comboBed = new JComboBox<>(bedOptions);
        comboBed.setBounds(200, 290, 160, 30);
        comboBed.setBackground(Color.WHITE);
        add(comboBed);

        // Buttons
        updateBtn = new JButton("Update Room");
        updateBtn.setBounds(60, 370, 130, 30);
        updateBtn.setBackground(Color.BLACK);
        updateBtn.setForeground(Color.WHITE);
        updateBtn.addActionListener(this);
        add(updateBtn);

        cancelBtn = new JButton("Cancel");
        cancelBtn.setBounds(220, 370, 130, 30);
        cancelBtn.setBackground(Color.BLACK);
        cancelBtn.setForeground(Color.WHITE);
        cancelBtn.addActionListener(this);
        add(cancelBtn);

        // Image
        try {
            ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/seventh.jpg")); 
            Image i2 = i1.getImage().getScaledInstance(530, 350, Image.SCALE_DEFAULT);
            ImageIcon i3 = new ImageIcon(i2);
            JLabel image = new JLabel(i3);
            image.setBounds(410, 50, 530, 350);
            add(image);
        } catch (Exception e) {
            System.out.println("Image not found");
        }

        loadRoomData();
        isFirstLoad = false; 
        setLocationRelativeTo(null); 
        setVisible(true);
    }

    public void itemStateChanged(ItemEvent ie) {
        loadRoomData(); 
    }

    public void loadRoomData() {
        String roomNum = cRoom.getSelectedItem();
        if(roomNum == null) return;
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from room where roomnumber = '" + roomNum + "'");
            if (rs.next()) {
                String availability = rs.getString("availability");
                comboAvailable.setSelectedItem(availability);
                tPrice.setText(rs.getString("price"));
                comboClean.setSelectedItem(rs.getString("cleaning_status")); 
                comboBed.setSelectedItem(rs.getString("bed_type"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == comboAvailable && !isFirstLoad) {
            String availability = (String) comboAvailable.getSelectedItem();
            if (availability.equals("Occupied")) {
                comboClean.setSelectedItem("Cleaned");
            } else {
                comboClean.setSelectedItem("Not Ready");
            }
        }
        
        if (ae.getSource() == updateBtn) {
            String roomNum = cRoom.getSelectedItem();
            String availability = (String) comboAvailable.getSelectedItem();
            String cleaning = (String) comboClean.getSelectedItem();
            String price = tPrice.getText();
            String bedType = (String) comboBed.getSelectedItem();

            try {
                Conn c = new Conn();
             
                String query = "update room set availability = '" + availability + "', cleaning_status = '" + cleaning + "', price = '" + price + "', bed_type = '" + bedType + "' where roomnumber = '" + roomNum + "'";
                c.s.executeUpdate(query);
                
                JOptionPane.showMessageDialog(null, "Room Details Updated Successfully!");
                setVisible(false);
                new Reception(); 
                
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (ae.getSource() == cancelBtn) {
            setVisible(false);
            new Reception();
        }
    }

    public static void main(String[] args) {
        new RoomChange();
    }
}
