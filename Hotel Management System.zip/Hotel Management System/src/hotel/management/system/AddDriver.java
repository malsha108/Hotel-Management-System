package hotel.management.system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class AddDriver extends JFrame implements ActionListener {

    JTextField tfname, tfage, tfcompany, tfbrand, tflocation;
    JComboBox<String> genderCombo, availableCombo;
    JButton add, back;

    AddDriver() {

        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel heading = new JLabel("Add Driver");
        heading.setFont(new Font("Tahoma", Font.BOLD, 18));
        heading.setBounds(150, 20, 200, 30);
        add(heading);

        JLabel lblname = new JLabel("Name");
        lblname.setBounds(60, 80, 120, 30);
        add(lblname);

        tfname = new JTextField();
        tfname.setBounds(200, 80, 150, 30);
        add(tfname);

        JLabel lblage = new JLabel("Age");
        lblage.setBounds(60, 130, 120, 30);
        add(lblage);

        tfage = new JTextField();
        tfage.setBounds(200, 130, 150, 30);
        add(tfage);

        JLabel lblgender = new JLabel("Gender");
        lblgender.setBounds(60, 180, 120, 30);
        add(lblgender);

        genderCombo = new JComboBox<>(new String[]{"Male", "Female"});
        genderCombo.setBounds(200, 180, 150, 30);
        add(genderCombo);

        JLabel lblcompany = new JLabel("Car Company");
        lblcompany.setBounds(60, 230, 120, 30);
        add(lblcompany);

        tfcompany = new JTextField();
        tfcompany.setBounds(200, 230, 150, 30);
        add(tfcompany);

        JLabel lblbrand = new JLabel("Car Brand");
        lblbrand.setBounds(60, 280, 120, 30);
        add(lblbrand);

        tfbrand = new JTextField();
        tfbrand.setBounds(200, 280, 150, 30);
        add(tfbrand);

        JLabel lblavailable = new JLabel("Available");
        lblavailable.setBounds(60, 330, 120, 30);
        add(lblavailable);

        availableCombo = new JComboBox<>(new String[]{"Yes", "No"});
        availableCombo.setBounds(200, 330, 150, 30);
        add(availableCombo);

        JLabel lbllocation = new JLabel("Location");
        lbllocation.setBounds(60, 380, 120, 30);
        add(lbllocation);

        tflocation = new JTextField();
        tflocation.setBounds(200, 380, 150, 30);
        add(tflocation);

        add = new JButton("Add");
        add.setBounds(60, 430, 130, 30);
        add.setBackground(Color.BLACK);
        add.setForeground(Color.WHITE);
        add.addActionListener(this);
        add(add);

        back = new JButton("Back");
        back.setBounds(220, 430, 130, 30);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/eleven.jpg"));
        Image i2 = i1.getImage().getScaledInstance(500, 300, Image.SCALE_DEFAULT);
        JLabel image = new JLabel(new ImageIcon(i2));
        image.setBounds(400, 50, 500, 300);
        add(image);

        setBounds(300, 100, 950, 550);
        setLocationRelativeTo(null); 
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == add) {

            String name = tfname.getText();
            String age = tfage.getText();
            String gender = (String) genderCombo.getSelectedItem();
            String company = tfcompany.getText();
            String brand = tfbrand.getText();
            String available = (String) availableCombo.getSelectedItem();
            String location = tflocation.getText();

            // validation
            if (name.equals("") || age.equals("") || company.equals("") || brand.equals("") || location.equals("")) {
                JOptionPane.showMessageDialog(null, "Please fill all fields");
                return;
            }

            try {
                Conn conn = new Conn();

                String query = "INSERT INTO driver VALUES('" + name + "', '" + age + "', '" + gender + "', '" + company + "', '" + brand + "', '" + available + "', '" + location + "')";
                conn.s.executeUpdate(query);

                JOptionPane.showMessageDialog(null, "Driver Added Successfully");
                setVisible(false);

            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (ae.getSource() == back) {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new AddDriver();
    }
}