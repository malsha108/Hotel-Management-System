
package hotel.management.system;

import java.awt.Image;
import java.awt.Color;
import static java.awt.Color.WHITE;
import java.awt.Font;
import static java.time.temporal.TemporalAdjusters.next;
import java.util.HashSet;
import java.util.Set;
import javax.swing.*;
import java.awt.event.*;

public class HotelManagementSystem   extends JFrame implements ActionListener{

          HotelManagementSystem (){
              setSize(1366,565);
              setLocation(100,100);
              setLayout(null);
              
              ImageIcon i1 = new ImageIcon("C:\\Users\\HP\\OneDrive\\Documents\\NetBeansProjects\\Hotel Management System\\icons-20260316T160203Z-3-001\\icons\\first 1.jpg");
              JLabel image = new JLabel(i1);
              image.setBounds(0, 0, 1366, 565);//locationx,locationy,length,breadth
              add (image);
              JLabel text = new JLabel("HOTEL MANAGEMENT SYSTEM");
              text.setBounds(20, 430, 1000, 90);
              text.setForeground(WHITE);
              text.setFont(new Font("serif" ,Font.PLAIN,50));
            
              image.add(text);
              
              
              JButton next =new JButton("Next");
              next.setBounds(1150, 450, 150, 50);
              next.setBackground(WHITE);
              next.addActionListener(this);
              image.add(next);
              setVisible(true);
              
              while(true){
                  text.setVisible(false);
                  try{
                      Thread.sleep(500);
                  }catch(Exception e){
                      e.printStackTrace();
                  }
                  text.setVisible(true);
                  try{
                      Thread.sleep(500);
                  }catch(Exception e){
                      e.printStackTrace();
                  }
              }
          }
          
          public void actionPerformed(ActionEvent ae){
              setVisible(false);
                new Login();
                        }
    public static void main(String[] args) {
      new HotelManagementSystem();
    }

   
    
}
