package hotel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import net.proteanit.sql.DbUtils;

public class SearchRoom extends JFrame implements ActionListener {

    JTable table;
    JButton back, submit;
    JComboBox<String> bedType;
    JCheckBox available;

    SearchRoom() {

        setTitle("Search Room");
        setBounds(300, 200, 1000, 600);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel text = new JLabel("Search For Room");
        text.setFont(new Font("Tahoma", Font.BOLD, 20));
        text.setBounds(380, 20, 250, 30);
        add(text);

        // Bed Type
        JLabel lblbed = new JLabel("Bed Type");
        lblbed.setBounds(50, 80, 100, 25);
        add(lblbed);

        bedType = new JComboBox<>(new String[]{"Single Bed", "Double Bed"});
        bedType.setBounds(150, 80, 150, 25);
        add(bedType);

        // Checkbox
        available = new JCheckBox("Only Display Available");
        available.setBackground(Color.WHITE);
        available.setBounds(500, 80, 180, 25);
        add(available);

        // Table headings
        JLabel l1 = new JLabel("Room Number");
        l1.setBounds(50, 140, 100, 20);
        add(l1);

        JLabel l2 = new JLabel("Availability");
        l2.setBounds(220, 140, 100, 20);
        add(l2);

        JLabel l3 = new JLabel("Cleaning Status");
        l3.setBounds(400, 140, 120, 20);
        add(l3);

        JLabel l4 = new JLabel("Price");
        l4.setBounds(650, 140, 100, 20);
        add(l4);

        JLabel l5 = new JLabel("Bed Type");
        l5.setBounds(820, 140, 100, 20);
        add(l5);

        // Table
        table = new JTable();

        try {
            Conn conn = new Conn();
            ResultSet rs = conn.s.executeQuery("select * from room");
            table.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (Exception e) {
            e.printStackTrace();
        }

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 170, 950, 300);
        add(sp);

        // Submit button
        submit = new JButton("Submit");
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.WHITE);
        submit.setBounds(300, 500, 120, 30);
        submit.addActionListener(this);
        add(submit);

        // Back button
        back = new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.setBounds(500, 500, 120, 30);
        back.addActionListener(this);
        add(back);

        setLocationRelativeTo(null); 
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == submit) {

            try {

                String query1 = "select * from room where bed_type='" + bedType.getSelectedItem() + "'";

                String query2 = "select * from room where availability='Available' AND bed_type='" + bedType.getSelectedItem() + "'";

                Conn conn = new Conn();
                ResultSet rs;

                if (available.isSelected()) {

                    rs = conn.s.executeQuery(query2);

                } else {

                    rs = conn.s.executeQuery(query1);
                }

                table.setModel(DbUtils.resultSetToTableModel(rs));

            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (ae.getSource() == back) {

            setVisible(false);
            new Reception();
        }
    }

    public static void main(String[] args) {

        new SearchRoom();
    }
}
   

