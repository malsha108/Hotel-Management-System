
package hotel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AddDepartment extends JFrame implements ActionListener {

    JTextField t1, t2;
    JButton addBtn, backBtn;

    public AddDepartment() {
        setTitle("Add Department");
        setBounds(400, 200, 450, 350);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel heading = new JLabel("ADD DEPARTMENT");
        heading.setFont(new Font("Tahoma", Font.BOLD, 18));
        heading.setBounds(120, 20, 200, 30);
        add(heading);

        JLabel lblName = new JLabel("Department Name:");
        lblName.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblName.setBounds(40, 90, 130, 25);
        add(lblName);

        t1 = new JTextField();
        t1.setBounds(190, 90, 180, 25);
        add(t1);

        JLabel lblBudget = new JLabel("Budget:");
        lblBudget.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblBudget.setBounds(40, 150, 130, 25);
        add(lblBudget);

        t2 = new JTextField();
        t2.setBounds(190, 150, 180, 25);
        add(t2);

        // Add Button
        addBtn = new JButton("Add");
        addBtn.setBounds(80, 230, 110, 30);
        addBtn.setBackground(Color.BLACK);
        addBtn.setForeground(Color.WHITE);
        addBtn.addActionListener(this);
        add(addBtn);

        // Back Button
        backBtn = new JButton("Back");
        backBtn.setBounds(220, 230, 110, 30);
        backBtn.setBackground(Color.BLACK);
        backBtn.setForeground(Color.WHITE);
        backBtn.addActionListener(this);
        add(backBtn);

        setLocationRelativeTo(null); 
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == addBtn) {
            String department = t1.getText();
            String budget = t2.getText();

            if (department.equals("") || budget.equals("")) {
                JOptionPane.showMessageDialog(null, "Please fill all fields!");
                return;
            }

            try {
                Conn c = new Conn();
                String query = "insert into department values('" + department + "', '" + budget + "')";
                
                c.s.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Department Added Successfully!");
                
                setVisible(false);
                new Reception(); 
                
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
            }

        } else if (ae.getSource() == backBtn) {
            setVisible(false);
            new Reception();
        }
    }

    public static void main(String[] args) {
        new AddDepartment();
    }
}